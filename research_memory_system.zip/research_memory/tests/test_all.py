"""
tests/test_all.py — Test suite for Research Lab Memory System

Run: python -m pytest tests/ -v
Or:  python tests/test_all.py
"""

import sys
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))


# ── Preprocessor tests ────────────────────────────────────────────────────────
class TestPreprocessor(unittest.TestCase):

    def setUp(self):
        from modules.preprocessor import clean_text, split_sentences, chunk_text, preprocess_meeting
        self.clean = clean_text
        self.split = split_sentences
        self.chunk = chunk_text
        self.preprocess = preprocess_meeting

        self.sample = {
            "id": "test_001",
            "date": "2024-01-01",
            "title": "Test Meeting",
            "transcript": "We discussed BERT fine-tuning. Dr. Patel mentioned the deadline is March 15. Key idea: attention mechanism is core."
        }

    def test_clean_removes_urls(self):
        text = "See https://arxiv.org/abs/1234 for details."
        cleaned = self.clean(text)
        self.assertNotIn("https://", cleaned)

    def test_clean_collapses_whitespace(self):
        text = "Hello   world\n\n\ttesting"
        cleaned = self.clean(text)
        self.assertNotIn("   ", cleaned)
        self.assertNotIn("\n", cleaned)

    def test_split_sentences_returns_list(self):
        sentences = self.split("First sentence. Second sentence. Third one.")
        self.assertIsInstance(sentences, list)
        self.assertGreater(len(sentences), 1)

    def test_chunk_text_returns_overlapping(self):
        text = "Sentence one. Sentence two. Sentence three. Sentence four. Sentence five."
        chunks = self.chunk(text, chunk_size=2)
        self.assertIsInstance(chunks, list)
        self.assertGreater(len(chunks), 0)

    def test_preprocess_meeting_adds_fields(self):
        result = self.preprocess(self.sample)
        self.assertIn("clean_text", result)
        self.assertIn("sentences", result)
        self.assertIn("chunks", result)
        self.assertGreater(len(result["sentences"]), 0)
        self.assertGreater(len(result["chunks"]), 0)


# ── Extractor tests ──────────────────────────────────────────────────────────
class TestExtractor(unittest.TestCase):

    def setUp(self):
        from modules.extractor import (
            extract_keywords_tfidf, extract_named_entities,
            extract_papers, extract_deadlines,
            extract_research_topics, extract_key_ideas,
        )
        self.keywords_fn = extract_keywords_tfidf
        self.entities_fn = extract_named_entities
        self.papers_fn = extract_papers
        self.deadlines_fn = extract_deadlines
        self.topics_fn = extract_research_topics
        self.ideas_fn = extract_key_ideas

        self.text = (
            "Dr. Patel discussed the attention mechanism paper by Vaswani et al. 2017. "
            "Key idea: multilingual BERT achieves 71% accuracy. "
            "Deadline: submit abstract to EMNLP by February 28. "
            "Sarah will implement the RAG pipeline using FAISS."
        )

    def test_keywords_tfidf_returns_list_of_tuples(self):
        results = self.keywords_fn([self.text], top_n=5)
        self.assertEqual(len(results), 1)
        self.assertIsInstance(results[0], list)
        if results[0]:
            self.assertEqual(len(results[0][0]), 2)  # (keyword, score)

    def test_keywords_scores_between_0_and_1(self):
        results = self.keywords_fn([self.text, "Another text about deep learning."], top_n=5)
        for doc_kw in results:
            for _, score in doc_kw:
                self.assertGreaterEqual(score, 0.0)
                self.assertLessEqual(score, 1.0)

    def test_entities_returns_dict(self):
        entities = self.entities_fn(self.text)
        self.assertIsInstance(entities, dict)
        self.assertIn("PERSON", entities)
        self.assertIn("DATE", entities)

    def test_entities_detects_person(self):
        entities = self.entities_fn(self.text)
        self.assertIn("Patel", entities["PERSON"])

    def test_entities_detects_date(self):
        entities = self.entities_fn(self.text)
        self.assertTrue(any("February" in d for d in entities["DATE"]))

    def test_papers_detects_et_al(self):
        papers = self.papers_fn(self.text)
        self.assertTrue(any("Vaswani" in p for p in papers))

    def test_deadlines_detects_submit(self):
        deadlines = self.deadlines_fn(self.text)
        self.assertGreater(len(deadlines), 0)
        self.assertTrue(any("submit" in d.lower() or "deadline" in d.lower() for d in deadlines))

    def test_research_topics_detects_rag(self):
        topics = self.topics_fn(self.text)
        self.assertTrue(any("rag" in t.lower() or "retrieval" in t.lower() for t in topics))

    def test_key_ideas_detects_key_idea(self):
        ideas = self.ideas_fn(self.text)
        self.assertGreater(len(ideas), 0)


# ── Embedder tests ───────────────────────────────────────────────────────────
class TestEmbedder(unittest.TestCase):

    def setUp(self):
        from modules.embedder import MeetingEmbedder
        self.EmbedderClass = MeetingEmbedder

    def test_embed_shape(self):
        embedder = self.EmbedderClass()
        texts = ["Hello world", "RAG pipeline test", "BERT fine-tuning"]
        embs = embedder.embed(texts)
        self.assertEqual(embs.shape[0], 3)
        self.assertEqual(embs.shape[1], 384)

    def test_embed_normalized(self):
        import numpy as np
        embedder = self.EmbedderClass()
        embs = embedder.embed(["Test sentence for normalization check"])
        norm = np.linalg.norm(embs[0])
        self.assertAlmostEqual(float(norm), 1.0, places=5)

    def test_build_and_search(self):
        from modules.preprocessor import preprocess_meeting
        from modules.extractor import extract_all

        meeting = preprocess_meeting({
            "id": "t001", "date": "2024-01-01",
            "title": "Test", "transcript":
            "We discussed the RAG pipeline. Key idea: FAISS enables semantic search. "
            "Deadline: demo by March 10. Paper by Gao et al. 2023 was reviewed."
        })
        enriched = extract_all(meeting, [meeting["clean_text"]], 0)

        embedder = self.EmbedderClass()
        embedder.build_index([enriched])

        results = embedder.search("semantic search FAISS", top_k=3)
        self.assertIsInstance(results, list)
        self.assertGreater(len(results), 0)
        self.assertIn("chunk", results[0])
        self.assertIn("score", results[0])
        self.assertGreaterEqual(results[0]["score"], 0.0)

    def test_search_score_ordering(self):
        """Results should be in descending score order."""
        from modules.preprocessor import preprocess_meeting
        from modules.extractor import extract_all

        meetings_data = [
            {"id": f"t{i}", "date": "2024-01-01", "title": f"M{i}",
             "transcript": f"Topic {i}: research on NLP and deep learning models."}
            for i in range(3)
        ]
        processed = [preprocess_meeting(m) for m in meetings_data]
        all_texts = [m["clean_text"] for m in processed]
        enriched = [extract_all(m, all_texts, i) for i, m in enumerate(processed)]

        embedder = self.EmbedderClass()
        embedder.build_index(enriched)
        results = embedder.search("NLP deep learning", top_k=5)

        scores = [r["score"] for r in results]
        self.assertEqual(scores, sorted(scores, reverse=True))


# ── Clusterer tests ──────────────────────────────────────────────────────────
class TestClusterer(unittest.TestCase):

    def test_cluster_chunks_basic(self):
        import numpy as np
        from modules.clusterer import cluster_chunks

        # Fake embeddings (2 obvious clusters)
        np.random.seed(42)
        embs_a = np.random.randn(5, 10) + np.array([5] * 10)
        embs_b = np.random.randn(5, 10) + np.array([-5] * 10)
        embs = np.vstack([embs_a, embs_b]).astype(np.float32)

        meta = [{"chunk": f"Chunk {i}", "meeting_id": f"m{i % 3}",
                 "keywords": ["nlp"], "topics": []} for i in range(10)]

        clusters = cluster_chunks(embs, meta, n_clusters=2)
        self.assertEqual(len(clusters), 2)
        total_chunks = sum(c["size"] for c in clusters)
        self.assertEqual(total_chunks, 10)

    def test_detect_trends_filters_by_meetings(self):
        from modules.clusterer import detect_trends

        clusters = [
            {"cluster_id": 0, "label": "NLP", "meetings": ["m1", "m2", "m3"],
             "chunks": [], "size": 5, "centroid": None},
            {"cluster_id": 1, "label": "CV", "meetings": ["m1"],
             "chunks": [], "size": 3, "centroid": None},
        ]
        trends = detect_trends(clusters, min_meetings=2)
        self.assertEqual(len(trends), 1)
        self.assertEqual(trends[0]["label"], "NLP")


# ── RAG Pipeline tests ───────────────────────────────────────────────────────
class TestRAG(unittest.TestCase):

    def test_build_context(self):
        from modules.rag_pipeline import build_context
        results = [
            {"chunk": "BERT was discussed.", "meeting_title": "Meeting 1", "date": "2024-01-01"},
            {"chunk": "RAG pipeline built.", "meeting_title": "Meeting 2", "date": "2024-01-08"},
        ]
        context = build_context(results)
        self.assertIn("BERT", context)
        self.assertIn("RAG", context)
        self.assertIn("Meeting 1", context)

    def test_build_prompt_structure(self):
        from modules.rag_pipeline import build_prompt
        prompt = build_prompt("What papers were discussed?", "Context here.")
        self.assertIn("MEETING CONTEXT:", prompt)
        self.assertIn("QUESTION:", prompt)
        self.assertIn("What papers were discussed?", prompt)
        self.assertIn("Context here.", prompt)


# ── Integration test ─────────────────────────────────────────────────────────
class TestIntegration(unittest.TestCase):

    def test_full_pipeline_on_sample_data(self):
        """End-to-end test: load data → preprocess → extract → embed → search."""
        from modules.preprocessor import load_meetings, preprocess_all
        from modules.extractor import extract_all
        from modules.embedder import MeetingEmbedder

        data_path = ROOT / "data" / "meetings.json"
        self.assertTrue(data_path.exists(), "meetings.json not found")

        raw = load_meetings(str(data_path))
        self.assertGreater(len(raw), 0)

        processed = preprocess_all(raw)
        all_texts = [m["clean_text"] for m in processed]
        enriched = [extract_all(m, all_texts, i) for i, m in enumerate(processed)]

        # Check extraction produced results
        for m in enriched:
            self.assertIn("keywords", m)
            self.assertIn("entities", m)
            self.assertIn("deadlines", m)
            self.assertGreater(len(m.get("chunks", [])), 0)

        # Build index and search
        embedder = MeetingEmbedder()
        embedder.build_index(enriched)

        results = embedder.search("RAG pipeline FAISS vector search", top_k=3)
        self.assertGreater(len(results), 0)
        self.assertGreater(results[0]["score"], 0.3)  # Should find relevant content

        print(f"\n✅ Integration test passed: {len(enriched)} meetings, {embedder.index.ntotal} vectors indexed")
        print(f"   Top search result: [{results[0]['score']:.3f}] {results[0]['meeting_title']}")


# ── Runner ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Run with more verbose output
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    test_classes = [
        TestPreprocessor,
        TestExtractor,
        TestEmbedder,
        TestClusterer,
        TestRAG,
        TestIntegration,
    ]

    for cls in test_classes:
        suite.addTests(loader.loadTestsFromTestCase(cls))

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    if result.wasSuccessful():
        print("\n✅ All tests passed!")
    else:
        print(f"\n❌ {len(result.failures)} failures, {len(result.errors)} errors")
        sys.exit(1)
