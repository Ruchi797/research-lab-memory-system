"""
Module: rag_pipeline.py
Purpose: Retrieval Augmented Generation (RAG) for Q&A over meeting transcripts.

Architecture:
  1. Retriever  → FAISS semantic search (our embedder.py)
  2. Augmentor  → Build context string from top-K retrieved chunks
  3. Generator  → Call LLM (OpenAI or local HuggingFace) with context + question

Two modes:
  - Mode A (API): Uses OpenAI GPT-3.5/4 — requires OPENAI_API_KEY env var
  - Mode B (Local): Uses a lightweight HuggingFace model — no API key needed

Default: Mode B (local) so the system works offline.
Local model: google/flan-t5-base — small (250MB), instruction-tuned, runs on CPU.

Why not LangChain's built-in FAISS vectorstore:
  - We already have our own FAISS index + metadata system
  - Avoids duplicate embedding overhead
  - Gives us full control over retrieval logic
  LangChain is used only for the prompt template + LLM chain.
"""

import os
import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


# ── Context builder ──────────────────────────────────────────────────────────
def build_context(search_results: List[Dict[str, Any]], max_tokens: int = 1500) -> str:
    """
    Build a context string from FAISS search results for the LLM prompt.

    Each chunk is prefixed with its source meeting and date.
    Context is truncated to max_tokens (approximate, by character count).

    Args:
        search_results: Output of embedder.search() — list of result dicts.
        max_tokens:     Approximate max context length in characters.

    Returns:
        Formatted context string.
    """
    context_parts = []
    total_chars = 0
    char_limit = max_tokens * 4  # ~4 chars per token

    for i, result in enumerate(search_results, 1):
        source = f"[Meeting: {result.get('meeting_title', 'Unknown')} | {result.get('date', '')}]"
        chunk = result.get("chunk", "")
        entry = f"{source}\n{chunk}"

        if total_chars + len(entry) > char_limit:
            break

        context_parts.append(entry)
        total_chars += len(entry)

    return "\n\n---\n\n".join(context_parts)


# ── Prompt template ──────────────────────────────────────────────────────────
def build_prompt(question: str, context: str) -> str:
    """
    Build the RAG prompt combining context + question.

    The prompt is designed for instruction-tuned models (flan-t5, GPT-3.5).
    It instructs the model to answer only from context and say "I don't know"
    if the answer isn't present — reducing hallucination.

    Args:
        question: User's natural language question.
        context:  Retrieved context from FAISS search.

    Returns:
        Complete prompt string.
    """
    prompt = f"""You are an AI assistant helping researchers understand their meeting history.
Answer the question using ONLY the provided meeting context below.
If the answer is not in the context, say: "I don't have enough information from the meetings to answer this."
Be concise and factual.

MEETING CONTEXT:
{context}

QUESTION: {question}

ANSWER:"""
    return prompt


# ── Local LLM (HuggingFace flan-t5-base) ────────────────────────────────────
class LocalRAG:
    """
    RAG pipeline using a local HuggingFace model (flan-t5-base).
    No API key required. Runs on CPU. Best for short factual answers.

    Why flan-t5-base:
      - Instruction-tuned → follows Q&A format well
      - 250MB, runs on CPU in ~2-5 seconds per query
      - Open source (Apache 2.0)

    Upgrade path: Replace with flan-t5-large (780MB) or mistral-7b-instruct
    (needs GPU) for better answer quality.
    """

    def __init__(self, model_name: str = "google/flan-t5-base"):
        logger.info(f"Loading local LLM: {model_name} (first run downloads model)")
        try:
            from transformers import pipeline as hf_pipeline
            self._pipe = hf_pipeline(
                "text2text-generation",
                model=model_name,
                max_new_tokens=256,
                device=-1,  # CPU
            )
            self._available = True
            logger.info("Local LLM ready")
        except Exception as e:
            logger.warning(f"Could not load local LLM: {e}. Falling back to rule-based answers.")
            self._pipe = None
            self._available = False

    def generate(self, prompt: str) -> str:
        """
        Generate an answer from the prompt.

        Args:
            prompt: Full RAG prompt (context + question).

        Returns:
            Generated answer string.
        """
        if not self._available or self._pipe is None:
            return self._fallback_answer(prompt)

        try:
            result = self._pipe(prompt, max_new_tokens=256, do_sample=False)
            return result[0]["generated_text"].strip()
        except Exception as e:
            logger.error(f"Generation failed: {e}")
            return self._fallback_answer(prompt)

    @staticmethod
    def _fallback_answer(prompt: str) -> str:
        """
        Rule-based fallback when LLM is unavailable.
        Extracts the context section and returns a message.
        """
        # Extract context from prompt for display
        if "MEETING CONTEXT:" in prompt and "QUESTION:" in prompt:
            context_start = prompt.index("MEETING CONTEXT:") + len("MEETING CONTEXT:")
            context_end = prompt.index("QUESTION:")
            context_preview = prompt[context_start:context_end].strip()[:300]
            return (
                f"[LLM unavailable — showing retrieved context]\n\n"
                f"{context_preview}..."
            )
        return "[LLM unavailable — please install transformers or set OPENAI_API_KEY]"


# ── OpenAI RAG (optional) ────────────────────────────────────────────────────
class OpenAIRAG:
    """
    RAG pipeline using OpenAI API.
    Requires: OPENAI_API_KEY environment variable.

    Better answer quality than local model but costs money.
    Use GPT-3.5-turbo for cost efficiency, GPT-4 for accuracy.
    """

    def __init__(self, model: str = "gpt-3.5-turbo"):
        self.model = model
        self._available = bool(os.getenv("OPENAI_API_KEY"))
        if not self._available:
            logger.warning("OPENAI_API_KEY not set. OpenAI RAG unavailable.")

    def generate(self, prompt: str) -> str:
        if not self._available:
            return "[OpenAI API key not configured]"

        try:
            from openai import OpenAI
            client = OpenAI()
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a research assistant."},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=512,
                temperature=0.1,  # Low temperature for factual answers
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            logger.error(f"OpenAI API call failed: {e}")
            return f"[OpenAI API error: {e}]"


# ── Main RAG Pipeline ────────────────────────────────────────────────────────
class RAGPipeline:
    """
    Full RAG pipeline: retrieval → context building → generation.

    Usage:
        rag = RAGPipeline(embedder)
        answer = rag.answer("What papers were discussed in January?")
    """

    def __init__(
        self,
        embedder,  # MeetingEmbedder instance
        llm_mode: str = "local",  # "local" or "openai"
        top_k: int = 5,
    ):
        """
        Args:
            embedder:  Initialized MeetingEmbedder with built index.
            llm_mode:  "local" uses flan-t5, "openai" uses GPT.
            top_k:     Number of chunks to retrieve per query.
        """
        self.embedder = embedder
        self.top_k = top_k

        if llm_mode == "openai" and os.getenv("OPENAI_API_KEY"):
            self.llm = OpenAIRAG()
            logger.info("Using OpenAI RAG")
        else:
            self.llm = LocalRAG()
            logger.info("Using Local RAG (flan-t5-base)")

    def answer(
        self, question: str, return_sources: bool = True
    ) -> Dict[str, Any]:
        """
        Answer a question using RAG.

        Pipeline:
          1. Semantic search for relevant chunks
          2. Build context string
          3. Build prompt
          4. Generate answer with LLM

        Args:
            question:       Natural language question.
            return_sources: Whether to include retrieved sources in output.

        Returns:
            Dict with:
              - "answer": str
              - "sources": List[Dict] (if return_sources=True)
              - "context": str (context passed to LLM)
              - "question": str
        """
        # Step 1: Retrieve relevant chunks
        search_results = self.embedder.search(question, top_k=self.top_k)

        if not search_results:
            return {
                "question": question,
                "answer": "No relevant meeting content found.",
                "sources": [],
                "context": "",
            }

        # Step 2: Build context
        context = build_context(search_results)

        # Step 3: Build prompt
        prompt = build_prompt(question, context)

        # Step 4: Generate answer
        answer = self.llm.generate(prompt)

        result = {
            "question": question,
            "answer": answer,
            "context": context,
        }

        if return_sources:
            result["sources"] = [
                {
                    "meeting_title": r.get("meeting_title"),
                    "date": r.get("date"),
                    "score": r.get("score"),
                    "chunk": r.get("chunk", "")[:200] + "...",
                }
                for r in search_results
            ]

        return result

    def summarize_meeting(self, meeting_id: str, meetings: List[Dict]) -> str:
        """
        Generate an AI summary for a specific meeting using RAG.

        Args:
            meeting_id: The meeting ID to summarize.
            meetings:   List of all processed meeting dicts.

        Returns:
            AI-generated summary string.
        """
        meeting = next((m for m in meetings if m["id"] == meeting_id), None)
        if not meeting:
            return "Meeting not found."

        question = f"Summarize the key points, decisions, and action items from the meeting titled '{meeting.get('title', meeting_id)}'."
        result = self.answer(question)
        return result["answer"]


# ── Quick self-test ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).parent))
    from preprocessor import load_meetings, preprocess_all
    from extractor import extract_all
    from embedder import MeetingEmbedder

    data_path = Path(__file__).parent.parent / "data" / "meetings.json"
    raw = load_meetings(str(data_path))
    processed = preprocess_all(raw)
    all_texts = [m["clean_text"] for m in processed]
    enriched = [extract_all(m, all_texts, i) for i, m in enumerate(processed)]

    embedder = MeetingEmbedder()
    embedder.build_index(enriched)

    rag = RAGPipeline(embedder, llm_mode="local")

    questions = [
        "What papers were discussed across all meetings?",
        "What are the main deadlines mentioned?",
        "What is the cross-lingual transfer approach?",
    ]

    for q in questions:
        result = rag.answer(q)
        print(f"\nQ: {q}")
        print(f"A: {result['answer'][:200]}")
        print(f"Sources: {[s['meeting_title'] for s in result['sources']]}")
