"""
Module: preprocessor.py
Purpose: Clean and tokenize raw meeting transcripts.

Steps:
  1. Lowercase and strip whitespace
  2. Remove noise characters (URLs, special chars)
  3. Sentence tokenize using spaCy sentencizer (no model download needed)
  4. Paragraph chunking for embedding
"""

import re
import json
import logging
from pathlib import Path
from typing import List, Dict, Any

import spacy
from spacy.lang.en import English

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


# ── Build a lightweight spaCy pipeline (no pretrained model needed) ──────────
def _build_nlp() -> spacy.Language:
    """
    Returns a blank English spaCy pipeline with only a sentencizer.
    This avoids downloading large model files while still giving us
    sentence boundary detection.
    """
    nlp = English()
    nlp.add_pipe("sentencizer")
    return nlp


_NLP = _build_nlp()


# ── Text cleaning ────────────────────────────────────────────────────────────
def clean_text(text: str) -> str:
    """
    Remove URLs, excessive whitespace, and non-ASCII noise.
    Keeps punctuation because it matters for sentence splitting.

    Args:
        text: Raw transcript string.

    Returns:
        Cleaned string.
    """
    # Remove URLs
    text = re.sub(r"http\S+|www\.\S+", "", text)
    # Collapse multiple spaces / newlines into single space
    text = re.sub(r"\s+", " ", text)
    # Strip leading/trailing whitespace
    text = text.strip()
    return text


# ── Sentence tokenization ────────────────────────────────────────────────────
def split_sentences(text: str) -> List[str]:
    """
    Split cleaned text into individual sentences using spaCy sentencizer.

    Args:
        text: Cleaned transcript text.

    Returns:
        List of sentence strings.
    """
    doc = _NLP(text)
    sentences = [sent.text.strip() for sent in doc.sents if sent.text.strip()]
    return sentences


# ── Chunking for embedding ───────────────────────────────────────────────────
def chunk_text(text: str, chunk_size: int = 3) -> List[str]:
    """
    Group sentences into overlapping chunks for embedding.
    Overlapping windows prevent context loss at chunk boundaries.

    Args:
        text:       Cleaned transcript text.
        chunk_size: Number of sentences per chunk.

    Returns:
        List of chunk strings.
    """
    sentences = split_sentences(text)
    chunks = []
    # Slide with step=1 so each sentence appears in multiple chunks (overlap)
    for i in range(0, len(sentences), max(1, chunk_size - 1)):
        chunk = " ".join(sentences[i : i + chunk_size])
        if chunk:
            chunks.append(chunk)
    return chunks


# ── Meeting-level preprocessing ──────────────────────────────────────────────
def preprocess_meeting(meeting: Dict[str, Any]) -> Dict[str, Any]:
    """
    Preprocess a single meeting dict.

    Input shape:  {"id": ..., "date": ..., "title": ..., "transcript": ...}
    Output shape: adds "clean_text", "sentences", "chunks" keys.

    Args:
        meeting: Raw meeting dict.

    Returns:
        Enriched meeting dict with processed fields.
    """
    raw = meeting.get("transcript", "")
    cleaned = clean_text(raw)
    sentences = split_sentences(cleaned)
    chunks = chunk_text(cleaned)

    return {
        **meeting,
        "clean_text": cleaned,
        "sentences": sentences,
        "chunks": chunks,
    }


# ── Batch preprocessing ──────────────────────────────────────────────────────
def preprocess_all(meetings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Preprocess a list of meetings.

    Args:
        meetings: List of raw meeting dicts.

    Returns:
        List of preprocessed meeting dicts.
    """
    processed = []
    for m in meetings:
        result = preprocess_meeting(m)
        logger.info(
            f"Preprocessed [{result['id']}]: "
            f"{len(result['sentences'])} sentences, "
            f"{len(result['chunks'])} chunks"
        )
        processed.append(result)
    return processed


# ── Load from JSON file ──────────────────────────────────────────────────────
def load_meetings(path: str = "data/meetings.json") -> List[Dict[str, Any]]:
    """
    Load raw meeting data from a JSON file.

    Args:
        path: Relative or absolute path to JSON file.

    Returns:
        List of raw meeting dicts.
    """
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ── Quick self-test ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    data_path = Path(__file__).parent.parent / "data" / "meetings.json"
    meetings = load_meetings(str(data_path))
    processed = preprocess_all(meetings)

    sample = processed[0]
    print(f"\nMeeting: {sample['title']}")
    print(f"Sentences ({len(sample['sentences'])}):")
    for s in sample["sentences"][:3]:
        print(f"  - {s}")
    print(f"Chunks ({len(sample['chunks'])}):")
    print(f"  - {sample['chunks'][0][:100]}...")
