"""
Module: embedder.py
Purpose: Generate sentence embeddings and manage the FAISS vector store.

Model choice: all-MiniLM-L6-v2
  - Why: Best speed/quality tradeoff for semantic search on short texts.
  - 384-dim vectors, ~22MB model, runs on CPU in <100ms per batch.
  - Better than larger models (all-mpnet-base-v2) for this use case because
    meeting chunks are short (3-5 sentences), not long documents.

FAISS index type: IndexFlatIP (Inner Product / cosine similarity)
  - Why not IVF or HNSW? At < 10K documents, flat search is fast enough
    and exact (no approximation error). Switch to IndexIVFFlat at 50K+ docs.
"""

import os
import pickle
import logging
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

logger = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────
MODEL_NAME = "all-MiniLM-L6-v2"
EMBEDDING_DIM = 384
INDEX_PATH = "data/faiss_index.bin"
METADATA_PATH = "data/faiss_metadata.pkl"


# ── Embedder class ───────────────────────────────────────────────────────────
class MeetingEmbedder:
    """
    Manages sentence embeddings and FAISS vector search for meeting chunks.

    Usage:
        embedder = MeetingEmbedder()
        embedder.build_index(meetings)              # Build from scratch
        results = embedder.search("RAG pipeline", top_k=5)
    """

    def __init__(self, model_name: str = MODEL_NAME):
        logger.info(f"Loading embedding model: {model_name}")
        # normalize_embeddings=True → cosine similarity via inner product
        self.model = SentenceTransformer(model_name)
        self.index: Optional[faiss.Index] = None
        # Metadata parallel to index: each entry stores chunk + source info
        self.metadata: List[Dict[str, Any]] = []

    # ── Embed a list of strings ──────────────────────────────────────────────
    def embed(self, texts: List[str], batch_size: int = 64) -> np.ndarray:
        """
        Generate normalized embeddings for a list of texts.

        Args:
            texts:      List of strings to embed.
            batch_size: Number of texts per forward pass (memory control).

        Returns:
            numpy array of shape (len(texts), EMBEDDING_DIM), float32, L2-norm=1.
        """
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            normalize_embeddings=True,   # L2-norm → cosine sim = dot product
            show_progress_bar=len(texts) > 100,
        )
        return embeddings.astype(np.float32)

    # ── Build FAISS index from meetings ─────────────────────────────────────
    def build_index(self, meetings: List[Dict[str, Any]]) -> None:
        """
        Build FAISS index from meeting chunks.

        For each meeting, each chunk becomes a searchable vector.
        Metadata stores: chunk text, meeting_id, meeting_title, date.

        Args:
            meetings: List of preprocessed+extracted meeting dicts.
                      Each must have 'chunks', 'id', 'title', 'date'.
        """
        all_chunks: List[str] = []
        all_metadata: List[Dict[str, Any]] = []

        for meeting in meetings:
            for chunk_idx, chunk in enumerate(meeting.get("chunks", [])):
                all_chunks.append(chunk)
                all_metadata.append({
                    "chunk": chunk,
                    "meeting_id": meeting["id"],
                    "meeting_title": meeting.get("title", ""),
                    "date": meeting.get("date", ""),
                    "chunk_idx": chunk_idx,
                    # Pass extracted fields through for display
                    "keywords": [k for k, _ in meeting.get("keywords", [])[:5]],
                    "topics": meeting.get("research_topics", []),
                })

        if not all_chunks:
            raise ValueError("No chunks found. Run preprocessor first.")

        logger.info(f"Embedding {len(all_chunks)} chunks...")
        embeddings = self.embed(all_chunks)

        # Build flat inner-product index (exact cosine search)
        self.index = faiss.IndexFlatIP(EMBEDDING_DIM)
        self.index.add(embeddings)
        self.metadata = all_metadata

        logger.info(f"FAISS index built: {self.index.ntotal} vectors")

    # ── Semantic search ──────────────────────────────────────────────────────
    def search(
        self, query: str, top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Semantic search: find top-K chunks most similar to the query.

        Args:
            query:  Natural language search query.
            top_k:  Number of results to return.

        Returns:
            List of result dicts with 'score', 'chunk', 'meeting_title', etc.
        """
        if self.index is None:
            raise RuntimeError("Index not built. Call build_index() first.")

        # Embed query (single string → shape (1, 384))
        query_vec = self.embed([query])

        # FAISS returns distances (inner product = cosine sim for normalized vecs)
        scores, indices = self.index.search(query_vec, top_k)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:  # FAISS returns -1 for empty slots
                continue
            result = {
                "score": float(round(score, 4)),
                **self.metadata[idx],
            }
            results.append(result)

        return results

    # ── Persist index to disk ────────────────────────────────────────────────
    def save(
        self,
        index_path: str = INDEX_PATH,
        metadata_path: str = METADATA_PATH,
    ) -> None:
        """
        Save FAISS index and metadata to disk for reuse.

        Args:
            index_path:    Path to save binary FAISS index.
            metadata_path: Path to save pickled metadata list.
        """
        if self.index is None:
            raise RuntimeError("Nothing to save. Build index first.")

        Path(index_path).parent.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self.index, index_path)
        with open(metadata_path, "wb") as f:
            pickle.dump(self.metadata, f)
        logger.info(f"Index saved → {index_path}, metadata → {metadata_path}")

    # ── Load index from disk ─────────────────────────────────────────────────
    def load(
        self,
        index_path: str = INDEX_PATH,
        metadata_path: str = METADATA_PATH,
    ) -> bool:
        """
        Load a previously saved FAISS index and metadata.

        Args:
            index_path:    Path to binary FAISS index.
            metadata_path: Path to pickled metadata list.

        Returns:
            True if loaded successfully, False if files don't exist.
        """
        if not (Path(index_path).exists() and Path(metadata_path).exists()):
            logger.warning("Index files not found. Need to rebuild.")
            return False

        self.index = faiss.read_index(index_path)
        with open(metadata_path, "rb") as f:
            self.metadata = pickle.load(f)
        logger.info(f"Index loaded: {self.index.ntotal} vectors")
        return True

    # ── Get embedding for a single text ─────────────────────────────────────
    def get_embedding(self, text: str) -> np.ndarray:
        """Return normalized embedding for one text string."""
        return self.embed([text])[0]

    # ── Get all embeddings from index ────────────────────────────────────────
    def get_all_embeddings(self) -> np.ndarray:
        """
        Reconstruct all stored embeddings from the FAISS index.
        Used by the clusterer module.

        Returns:
            numpy array of shape (n_vectors, EMBEDDING_DIM).
        """
        if self.index is None:
            raise RuntimeError("Index not built.")
        n = self.index.ntotal
        embeddings = np.zeros((n, EMBEDDING_DIM), dtype=np.float32)
        self.index.reconstruct_n(0, n, embeddings)
        return embeddings


# ── Quick self-test ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    import json
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).parent))
    from preprocessor import load_meetings, preprocess_all
    from extractor import extract_all

    data_path = Path(__file__).parent.parent / "data" / "meetings.json"
    raw = load_meetings(str(data_path))
    processed = preprocess_all(raw)
    all_texts = [m["clean_text"] for m in processed]
    enriched = [extract_all(m, all_texts, i) for i, m in enumerate(processed)]

    # Build index
    embedder = MeetingEmbedder()
    embedder.build_index(enriched)

    # Test search
    query = "RAG pipeline for question answering"
    results = embedder.search(query, top_k=3)
    print(f"\nQuery: '{query}'")
    for r in results:
        print(f"  [{r['score']:.3f}] {r['meeting_title']} — {r['chunk'][:80]}...")

    # Save
    save_dir = Path(__file__).parent.parent / "data"
    embedder.save(
        str(save_dir / "faiss_index.bin"),
        str(save_dir / "faiss_metadata.pkl"),
    )
    print("\nIndex saved successfully.")
