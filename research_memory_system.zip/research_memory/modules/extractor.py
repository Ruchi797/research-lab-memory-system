"""
Module: extractor.py
Purpose: Extract structured insights from preprocessed meeting transcripts.

Extracts:
  - Keywords       → TF-IDF on corpus
  - Named Entities → Rule-based patterns (person names, orgs, dates)
  - Research topics → Pattern matching + keyword clusters
  - Paper mentions  → Citation-like patterns (Author et al., conference names)
  - Deadlines       → Date + action phrase detection
  - Key ideas       → Sentences containing "key idea", "important", "finding"
"""

import re
import logging
from typing import List, Dict, Any, Tuple

import spacy
from spacy.lang.en import English
from spacy.matcher import Matcher, PhraseMatcher
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

logger = logging.getLogger(__name__)


# ── spaCy setup (rule-based, no pretrained model needed) ─────────────────────
def _build_nlp_with_rules() -> Tuple[spacy.Language, Matcher, PhraseMatcher]:
    """
    Build a blank English pipeline with custom rule-based matchers.
    Returns the nlp object, a token Matcher, and a PhraseMatcher.
    """
    nlp = English()
    nlp.add_pipe("sentencizer")

    # Token matcher for deadline patterns, paper mentions, ideas
    matcher = Matcher(nlp.vocab)

    # Deadline pattern: "deadline: ...", "due by ...", "submit by ..."
    matcher.add("DEADLINE", [
        [{"LOWER": {"IN": ["deadline", "due", "submit", "submission"]}},
         {"LOWER": {"IN": [":", "by", "on"]}, "OP": "?"},
         {"IS_ALPHA": True, "OP": "?"},
         {"LIKE_NUM": True, "OP": "?"}],
    ])

    # Key idea signal pattern
    matcher.add("KEY_IDEA", [
        [{"LOWER": {"IN": ["key", "important", "main", "core", "critical"]}},
         {"LOWER": {"IN": ["idea", "finding", "insight", "contribution", "point"]}},
         {"IS_PUNCT": True, "OP": "?"}],
        [{"LOWER": "key"}, {"LOWER": "takeaway"}],
    ])

    # PhraseMatcher for research area terms
    phrase_matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
    research_terms = [
        "machine learning", "deep learning", "natural language processing",
        "nlp", "computer vision", "reinforcement learning", "transfer learning",
        "fine-tuning", "bert", "gpt", "transformer", "attention mechanism",
        "retrieval augmented generation", "rag", "faiss", "embeddings",
        "sentiment analysis", "named entity recognition", "topic modeling",
        "data augmentation", "zero-shot", "few-shot", "cross-lingual",
        "multilingual", "low-resource", "evaluation metrics", "f1 score",
        "bleu score", "domain adaptation",
    ]
    patterns = [nlp.make_doc(term) for term in research_terms]
    phrase_matcher.add("RESEARCH_TOPIC", patterns)

    return nlp, matcher, phrase_matcher


_NLP, _MATCHER, _PHRASE_MATCHER = _build_nlp_with_rules()


# ── TF-IDF Keyword Extraction ────────────────────────────────────────────────
def extract_keywords_tfidf(
    documents: List[str], top_n: int = 10
) -> List[List[Tuple[str, float]]]:
    """
    Extract top-N keywords per document using TF-IDF.

    Why TF-IDF here (not KeyBERT or YAKE):
    - No external model download required
    - Works well for domain-specific jargon in research transcripts
    - Fast and interpretable

    Args:
        documents: List of cleaned transcript strings (one per meeting).
        top_n:     Number of keywords to return per document.

    Returns:
        List of lists: each inner list is [(keyword, score), ...] for one doc.
    """
    # Unigrams + bigrams. min_df=1 because corpus is small (5-50 meetings).
    vectorizer = TfidfVectorizer(
        ngram_range=(1, 2),
        stop_words="english",
        max_features=5000,
        min_df=1,
    )
    tfidf_matrix = vectorizer.fit_transform(documents)
    feature_names = vectorizer.get_feature_names_out()

    results = []
    for row in tfidf_matrix:
        # Get non-zero scores for this document
        scores = zip(feature_names, row.toarray()[0])
        sorted_scores = sorted(scores, key=lambda x: x[1], reverse=True)
        # Keep top_n non-empty terms
        top = [(term, round(score, 4)) for term, score in sorted_scores
               if score > 0 and len(term) > 2][:top_n]
        results.append(top)

    return results


# ── Named Entity Extraction ──────────────────────────────────────────────────
def extract_named_entities(text: str) -> Dict[str, List[str]]:
    """
    Extract named entities using rule-based patterns.

    Categories detected:
      - PERSON:  Capitalized names, "Dr./Prof. Name" patterns
      - ORG:     Known org keywords (ACL, EMNLP, arXiv, etc.)
      - DATE:    Month + day/year patterns
      - VENUE:   Conference names

    Args:
        text: Cleaned transcript text.

    Returns:
        Dict with entity type → list of unique entities.
    """
    entities: Dict[str, List[str]] = {
        "PERSON": [], "ORG": [], "DATE": [], "VENUE": []
    }

    # PERSON: "Dr. Lastname", "Prof. Lastname", or capitalized word before verb
    person_pattern = re.compile(
        r"\b(?:Dr\.|Prof\.|Professor)\s+([A-Z][a-z]+)|"
        r"\b([A-Z][a-z]{2,})\s+(?:mentioned|suggested|presented|reviewed|will|said)\b"
    )
    for m in person_pattern.finditer(text):
        name = m.group(1) or m.group(2)
        if name and name not in entities["PERSON"]:
            entities["PERSON"].append(name)

    # First names (simple capitalized word not at sentence start)
    first_name_pat = re.compile(r"(?<=\. )([A-Z][a-z]{2,})\s+(?:will|and|also)\b")
    for m in first_name_pat.finditer(text):
        name = m.group(1)
        if name and name not in entities["PERSON"]:
            entities["PERSON"].append(name)

    # ORG: Conferences, journals, companies commonly seen in research
    org_keywords = [
        "ACL", "EMNLP", "NAACL", "ICLR", "NeurIPS", "ICML", "AAAI",
        "arXiv", "Kaggle", "Hugging Face", "Google", "OpenAI", "Meta AI",
    ]
    for org in org_keywords:
        if org.lower() in text.lower() and org not in entities["ORG"]:
            entities["ORG"].append(org)

    # DATE: "February 28", "March 15", "January 31", "April 15"
    date_pattern = re.compile(
        r"\b(January|February|March|April|May|June|July|August|"
        r"September|October|November|December)\s+\d{1,2}(?:,\s*\d{4})?\b"
    )
    for m in date_pattern.finditer(text):
        date = m.group(0)
        if date not in entities["DATE"]:
            entities["DATE"].append(date)

    # VENUE: Conference name patterns
    venue_pat = re.compile(r"\b(ACL|EMNLP|NAACL|ICLR|NeurIPS|ICML|AAAI)\s+\d{4}\b")
    for m in venue_pat.finditer(text):
        venue = m.group(0)
        if venue not in entities["VENUE"]:
            entities["VENUE"].append(venue)

    return entities


# ── Paper/Citation Extraction ────────────────────────────────────────────────
def extract_papers(text: str) -> List[str]:
    """
    Detect paper references in the transcript.

    Patterns detected:
      - "Author et al. YEAR"
      - "paper on X by Y"
      - "paper by X"
      - "X paper" where X is a known model/method name

    Args:
        text: Cleaned transcript text.

    Returns:
        List of unique paper reference strings.
    """
    papers = []

    # "AuthorName et al. 2023" pattern
    et_al = re.compile(r"([A-Z][a-z]+(?:\s+et\s+al\.?)?)\s+(?:20|19)\d{2}")
    for m in et_al.finditer(text):
        papers.append(m.group(0).strip())

    # "paper on X by Y" or "paper by X"
    paper_by = re.compile(
        r"(?:paper|work|study)\s+(?:on\s+[\w\s]{2,30}\s+)?by\s+([A-Z][a-z]+(?:\s+et\s+al\.?)?)"
    )
    for m in paper_by.finditer(text):
        papers.append(m.group(0).strip())

    # Deduplicate and clean
    return list(dict.fromkeys(p for p in papers if len(p) > 4))


# ── Deadline Extraction ──────────────────────────────────────────────────────
def extract_deadlines(text: str) -> List[str]:
    """
    Extract deadline sentences from the transcript.

    Looks for sentences containing:
      - Date + action words (submit, deadline, due, review)
      - "by [month day]" patterns

    Args:
        text: Cleaned transcript text.

    Returns:
        List of sentences that contain deadline information.
    """
    deadline_keywords = re.compile(
        r"\b(deadline|due|submit|submission|deliver|complete|finish|by\s+(?:January|February|March|April|May|June|July|August|September|October|November|December))\b",
        re.IGNORECASE,
    )

    doc = _NLP(text)
    deadlines = []
    for sent in doc.sents:
        if deadline_keywords.search(sent.text):
            deadlines.append(sent.text.strip())

    return deadlines


# ── Research Topic Extraction ────────────────────────────────────────────────
def extract_research_topics(text: str) -> List[str]:
    """
    Identify research topic phrases using the PhraseMatcher.

    Args:
        text: Cleaned transcript text.

    Returns:
        List of unique research topic strings found in the text.
    """
    doc = _NLP(text)
    matches = _PHRASE_MATCHER(doc)
    topics = []
    for _, start, end in matches:
        topic = doc[start:end].text.lower()
        if topic not in topics:
            topics.append(topic)
    return topics


# ── Key Idea Extraction ──────────────────────────────────────────────────────
def extract_key_ideas(text: str) -> List[str]:
    """
    Extract sentences that contain key idea signal phrases.

    Signal phrases: "key idea", "important finding", "main contribution",
    "key finding", "critical insight", etc.

    Args:
        text: Cleaned transcript text.

    Returns:
        List of key idea sentences.
    """
    idea_signals = re.compile(
        r"\b(key\s+idea|key\s+finding|key\s+takeaway|important\s+(idea|finding|insight)|"
        r"main\s+(contribution|finding|idea)|core\s+(contribution|idea)|"
        r"critical\s+insight|we\s+found|result\s+shows?|this\s+shows?)\b",
        re.IGNORECASE,
    )

    doc = _NLP(text)
    ideas = []
    for sent in doc.sents:
        if idea_signals.search(sent.text):
            ideas.append(sent.text.strip())

    return ideas


# ── Summary Generation (extractive) ─────────────────────────────────────────
def extractive_summary(text: str, num_sentences: int = 3) -> str:
    """
    Simple extractive summary: pick the top-N sentences by word count
    (longer sentences tend to be more informative in meeting transcripts).

    This is intentionally simple — use the RAG module for AI summaries.

    Args:
        text:           Cleaned transcript text.
        num_sentences:  Number of sentences to include in summary.

    Returns:
        Summary string.
    """
    doc = _NLP(text)
    sentences = [s.text.strip() for s in doc.sents if len(s.text.split()) > 8]
    # Score by length (proxy for information density)
    scored = sorted(sentences, key=lambda s: len(s.split()), reverse=True)
    top = scored[:num_sentences]
    # Return in original order
    original_order = [s for s in sentences if s in top]
    return " ".join(original_order[:num_sentences])


# ── Full extraction pipeline for one meeting ────────────────────────────────
def extract_all(
    meeting: Dict[str, Any],
    all_clean_texts: List[str],
    meeting_index: int,
) -> Dict[str, Any]:
    """
    Run all extractors on a preprocessed meeting.

    Args:
        meeting:         Preprocessed meeting dict (has 'clean_text').
        all_clean_texts: List of clean texts from ALL meetings (for TF-IDF).
        meeting_index:   Index of this meeting in all_clean_texts.

    Returns:
        Meeting dict enriched with extracted fields.
    """
    text = meeting["clean_text"]

    # TF-IDF needs full corpus — extract for this doc only
    all_keywords = extract_keywords_tfidf(all_clean_texts)
    keywords = all_keywords[meeting_index]

    entities = extract_named_entities(text)
    papers = extract_papers(text)
    deadlines = extract_deadlines(text)
    topics = extract_research_topics(text)
    ideas = extract_key_ideas(text)
    summary = extractive_summary(text)

    return {
        **meeting,
        "keywords": keywords,
        "entities": entities,
        "papers_discussed": papers,
        "deadlines": deadlines,
        "research_topics": topics,
        "key_ideas": ideas,
        "summary": summary,
    }


# ── Quick self-test ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    import json
    from pathlib import Path
    import sys

    sys.path.insert(0, str(Path(__file__).parent))
    from preprocessor import load_meetings, preprocess_all

    data_path = Path(__file__).parent.parent / "data" / "meetings.json"
    raw = load_meetings(str(data_path))
    processed = preprocess_all(raw)

    all_texts = [m["clean_text"] for m in processed]
    enriched = extract_all(processed[0], all_texts, 0)

    print(f"\n=== {enriched['title']} ===")
    print(f"Keywords:  {[k for k, _ in enriched['keywords'][:5]]}")
    print(f"Entities:  {enriched['entities']}")
    print(f"Papers:    {enriched['papers_discussed']}")
    print(f"Deadlines: {enriched['deadlines']}")
    print(f"Topics:    {enriched['research_topics']}")
    print(f"Ideas:     {enriched['key_ideas']}")
    print(f"Summary:   {enriched['summary'][:150]}...")
