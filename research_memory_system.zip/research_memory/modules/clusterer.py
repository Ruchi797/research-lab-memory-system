"""
Module: clusterer.py
Purpose: Group meeting chunks into semantic clusters using KMeans.
         Detect cross-meeting trends (ideas that repeat across meetings).

Why KMeans over LDA (topic modeling):
  - We already have dense embeddings — KMeans in embedding space > LDA on bag-of-words
  - LDA requires tuning alpha/beta and works poorly on short texts (< 50 words/chunk)
  - KMeans gives deterministic, interpretable clusters
  - For production: replace with BERTopic (uses HDBSCAN + c-TF-IDF) for better
    topic labels. KMeans is used here to avoid heavy dependencies.

Optimal K selection: Elbow method (inertia vs K).
"""

import logging
from typing import List, Dict, Any, Tuple, Optional

import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

logger = logging.getLogger(__name__)


# ── Find optimal number of clusters ─────────────────────────────────────────
def find_optimal_k(
    embeddings: np.ndarray,
    k_range: Tuple[int, int] = (2, 10),
) -> int:
    """
    Use silhouette score to find optimal K for KMeans.

    Silhouette score (range -1 to 1): higher = better-defined clusters.
    More reliable than elbow method for small datasets.

    Args:
        embeddings: numpy array (n_samples, n_features).
        k_range:    (min_k, max_k) range to search.

    Returns:
        Optimal K value.
    """
    n_samples = embeddings.shape[0]
    # Can't have more clusters than samples
    max_k = min(k_range[1], n_samples - 1)
    min_k = max(k_range[0], 2)

    if min_k >= max_k:
        return min_k

    best_k = min_k
    best_score = -1.0

    for k in range(min_k, max_k + 1):
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = km.fit_predict(embeddings)
        # Silhouette requires at least 2 clusters and 2+ unique labels
        if len(set(labels)) < 2:
            continue
        score = silhouette_score(embeddings, labels, sample_size=min(500, n_samples))
        logger.debug(f"K={k}: silhouette={score:.4f}")
        if score > best_score:
            best_score = score
            best_k = k

    logger.info(f"Optimal K={best_k} (silhouette={best_score:.4f})")
    return best_k


# ── KMeans clustering ────────────────────────────────────────────────────────
def cluster_chunks(
    embeddings: np.ndarray,
    metadata: List[Dict[str, Any]],
    n_clusters: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Assign each chunk to a semantic cluster.

    Args:
        embeddings:  numpy array (n_chunks, embedding_dim).
        metadata:    Parallel list of chunk metadata dicts.
        n_clusters:  Number of clusters. If None, auto-selected.

    Returns:
        List of cluster dicts:
          {
            "cluster_id": int,
            "label": str,          # Auto-generated from top keywords
            "chunks": [...],       # Chunk texts in this cluster
            "meetings": [...],     # Meeting IDs contributing to this cluster
            "size": int,
            "centroid": np.array,
          }
    """
    n_samples = len(embeddings)
    if n_samples < 3:
        logger.warning("Too few chunks for clustering. Returning single cluster.")
        return [{
            "cluster_id": 0,
            "label": "All Topics",
            "chunks": [m["chunk"] for m in metadata],
            "meetings": list({m["meeting_id"] for m in metadata}),
            "size": n_samples,
        }]

    # Auto-select K if not provided
    if n_clusters is None:
        n_clusters = find_optimal_k(embeddings, k_range=(2, min(8, n_samples // 2)))

    logger.info(f"Running KMeans with K={n_clusters} on {n_samples} chunks")
    km = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = km.fit_predict(embeddings)

    # Build cluster summaries
    clusters = []
    for cluster_id in range(n_clusters):
        indices = [i for i, lbl in enumerate(labels) if lbl == cluster_id]
        cluster_chunks_text = [metadata[i]["chunk"] for i in indices]
        cluster_meetings = list({metadata[i]["meeting_id"] for i in indices})
        cluster_keywords = []
        for i in indices:
            cluster_keywords.extend(metadata[i].get("keywords", []))

        # Label: top 3 most frequent keywords in this cluster
        from collections import Counter
        kw_counts = Counter(cluster_keywords)
        top_kw = [kw for kw, _ in kw_counts.most_common(3)]
        label = " | ".join(top_kw) if top_kw else f"Cluster {cluster_id}"

        clusters.append({
            "cluster_id": cluster_id,
            "label": label,
            "chunks": cluster_chunks_text,
            "meetings": cluster_meetings,
            "size": len(indices),
            "centroid": km.cluster_centers_[cluster_id],
            "indices": indices,
        })

    # Sort by size descending
    clusters.sort(key=lambda c: c["size"], reverse=True)
    return clusters


# ── Cross-meeting trend detection ────────────────────────────────────────────
def detect_trends(
    clusters: List[Dict[str, Any]],
    min_meetings: int = 2,
) -> List[Dict[str, Any]]:
    """
    Identify ideas/topics that appear across multiple meetings.

    A "trend" = a cluster whose chunks span >= min_meetings different meetings.
    This tells you what the lab is consistently working on over time.

    Args:
        clusters:     Output of cluster_chunks().
        min_meetings: Minimum number of meetings a cluster must span.

    Returns:
        List of trend dicts with cluster info + trend metadata.
    """
    trends = []
    for cluster in clusters:
        if len(cluster["meetings"]) >= min_meetings:
            trends.append({
                **cluster,
                "trend_strength": len(cluster["meetings"]),  # # meetings it spans
                "is_recurring": True,
            })

    trends.sort(key=lambda t: t["trend_strength"], reverse=True)
    logger.info(f"Found {len(trends)} recurring trends (across {min_meetings}+ meetings)")
    return trends


# ── Repeated idea detection ──────────────────────────────────────────────────
def find_repeated_ideas(
    embeddings: np.ndarray,
    metadata: List[Dict[str, Any]],
    similarity_threshold: float = 0.85,
) -> List[Dict[str, Any]]:
    """
    Find semantically near-duplicate chunks across different meetings.

    Use case: detect when the same idea is discussed repeatedly
    (e.g., "cross-lingual transfer" mentioned in 3 different meetings).

    Method: pairwise cosine similarity on normalized embeddings.
    Complexity: O(n²) — fine for < 1000 chunks. Use FAISS batch search for larger.

    Args:
        embeddings:          Normalized chunk embeddings.
        metadata:            Parallel metadata list.
        similarity_threshold: Cosine similarity above which chunks are "same idea".

    Returns:
        List of repeated idea groups, each with matched chunks + meetings.
    """
    n = len(embeddings)
    if n > 500:
        logger.warning("Large corpus. Repeated idea detection may be slow.")

    # Cosine similarity matrix (embeddings already normalized → just dot product)
    sim_matrix = embeddings @ embeddings.T

    visited = set()
    groups = []

    for i in range(n):
        if i in visited:
            continue
        group_indices = [i]
        for j in range(i + 1, n):
            if j in visited:
                continue
            # Same meeting → skip (we want cross-meeting repetition)
            if metadata[i]["meeting_id"] == metadata[j]["meeting_id"]:
                continue
            if sim_matrix[i, j] >= similarity_threshold:
                group_indices.append(j)
                visited.add(j)

        if len(group_indices) > 1:
            visited.add(i)
            groups.append({
                "idea": metadata[i]["chunk"][:100] + "...",
                "occurrences": len(group_indices),
                "meetings": [metadata[k]["meeting_id"] for k in group_indices],
                "chunks": [metadata[k]["chunk"] for k in group_indices],
                "avg_similarity": float(np.mean([
                    sim_matrix[i, j] for j in group_indices[1:]
                ])),
            })

    groups.sort(key=lambda g: g["occurrences"], reverse=True)
    logger.info(f"Found {len(groups)} repeated ideas across meetings")
    return groups


# ── Quick self-test ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).parent))
    from preprocessor import load_meetings, preprocess_all
    from extractor import extract_all
    from embedder import MeetingEmbedder

    data_path = Path(__file__).parent.parent / "data" / "meetings.json"
    raw = load_meetings(str(data_path))
    processed = preprocess_all(raw)
    all_texts = [m["clean_text"] for m in processed]
    enriched = [extract_all(m, all_texts, i) for i, m in enumerate(processed)]

    embedder = MeetingEmbedder()
    embedder.build_index(enriched)

    embs = embedder.get_all_embeddings()
    meta = embedder.metadata

    # Cluster
    clusters = cluster_chunks(embs, meta)
    print(f"\n{len(clusters)} clusters found:")
    for c in clusters:
        print(f"  Cluster {c['cluster_id']} [{c['size']} chunks] '{c['label']}' — meetings: {c['meetings']}")

    # Trends
    trends = detect_trends(clusters, min_meetings=2)
    print(f"\n{len(trends)} trends (recurring across 2+ meetings):")
    for t in trends:
        print(f"  '{t['label']}' — {t['trend_strength']} meetings")

    # Repeated ideas
    repeated = find_repeated_ideas(embs, meta, similarity_threshold=0.80)
    print(f"\n{len(repeated)} repeated ideas detected:")
    for r in repeated:
        print(f"  '{r['idea'][:60]}...' — in {r['meetings']}")
