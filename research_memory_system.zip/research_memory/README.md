# 🧠 Research Lab Meeting Memory System

A production-level NLP system that processes meeting transcripts and extracts structured insights, supports semantic search, Q&A via RAG, and detects cross-meeting trends.

---

## 📁 Project Structure

```
research_memory/
├── app.py                    # Streamlit web app (entry point)
├── pipeline.py               # End-to-end orchestrator
├── requirements.txt
├── data/
│   ├── meetings.json         # Sample meeting transcripts
│   ├── faiss_index.bin       # Auto-generated FAISS index
│   └── faiss_metadata.pkl    # Auto-generated chunk metadata
├── modules/
│   ├── preprocessor.py       # Text cleaning + sentence/chunk splitting
│   ├── extractor.py          # TF-IDF keywords, NER, papers, deadlines, ideas
│   ├── embedder.py           # SentenceTransformer + FAISS index management
│   ├── clusterer.py          # KMeans clustering + trend detection
│   └── rag_pipeline.py       # RAG: context builder + LLM Q&A
└── tests/
    └── test_all.py           # Unit + integration tests
```

---

## 🚀 Setup & Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the web app
streamlit run app.py

# 3. Run tests
python tests/test_all.py
```

The first run downloads the `all-MiniLM-L6-v2` embedding model (~90MB) automatically.

---

## 🧩 Modules

### `preprocessor.py`
- `clean_text(text)` — remove URLs, normalize whitespace
- `split_sentences(text)` — spaCy sentencizer
- `chunk_text(text, chunk_size=3)` — overlapping sentence windows
- `preprocess_meeting(meeting)` — full preprocessing for one meeting

### `extractor.py`
- `extract_keywords_tfidf(docs, top_n=10)` — TF-IDF unigrams + bigrams
- `extract_named_entities(text)` — rule-based PERSON, ORG, DATE, VENUE
- `extract_papers(text)` — citation patterns ("Author et al. 2023")
- `extract_deadlines(text)` — deadline sentence detection
- `extract_research_topics(text)` — PhraseMatcher on research vocabulary
- `extract_key_ideas(text)` — "key idea / important finding" signal sentences

### `embedder.py`
- Model: `all-MiniLM-L6-v2` (384-dim, normalized, cosine similarity)
- `MeetingEmbedder.build_index(meetings)` — embed all chunks + build FAISS
- `MeetingEmbedder.search(query, top_k)` — semantic search
- `MeetingEmbedder.save() / load()` — persist index to disk

### `clusterer.py`
- `find_optimal_k(embeddings)` — silhouette score method
- `cluster_chunks(embeddings, metadata)` — KMeans with auto-K
- `detect_trends(clusters, min_meetings=2)` — cross-meeting recurring topics
- `find_repeated_ideas(embeddings, metadata)` — near-duplicate chunk detection

### `rag_pipeline.py`
- `LocalRAG` — uses `flan-t5-base` (no API key, CPU)
- `OpenAIRAG` — uses GPT-3.5/4 (needs `OPENAI_API_KEY`)
- `RAGPipeline.answer(question)` — full retrieve → augment → generate pipeline

---

## 🤖 Model Choices

| Task | Model | Why |
|------|-------|-----|
| Sentence embeddings | `all-MiniLM-L6-v2` | Best speed/quality for short texts, 384-dim |
| Keyword extraction | TF-IDF (sklearn) | No download, interpretable, works on small corpus |
| NER | Rule-based (spaCy) | No model download needed, tunable |
| Local LLM (RAG) | `flan-t5-base` | 250MB, instruction-tuned, CPU-friendly |
| OpenAI LLM (RAG) | `gpt-3.5-turbo` | Better quality, needs API key |
| Clustering | KMeans | Simple, works in embedding space, no extra deps |
| Vector search | FAISS IndexFlatIP | Exact cosine search, fast for <10K docs |

**Upgrade paths:**
- Embeddings → `all-mpnet-base-v2` for better quality on longer texts
- Clustering → BERTopic (HDBSCAN + c-TF-IDF) for better topic labels
- RAG LLM → `mistral-7b-instruct` (needs GPU) for much better answers
- FAISS → `IndexIVFFlat` when corpus exceeds 50K chunks

---

## 📊 Evaluation Metrics

| Component | Metric | Target |
|-----------|--------|--------|
| Keyword extraction | Manual relevance @ top-10 | >70% relevant |
| NER | Precision / Recall / F1 | >80% F1 |
| Semantic search | NDCG@5, MRR | NDCG > 0.7 |
| RAG answers | RAGAS: faithfulness, answer relevance | >0.80 |
| Clustering | Silhouette score | >0.30 |
| Trend detection | Manual validation of recurring themes | - |

---

## ⚙️ Configuration

**LLM mode** (sidebar in Streamlit app):
- `local` — uses flan-t5-base, no API key, slower answers
- `openai` — uses GPT-3.5, needs `OPENAI_API_KEY` env var, better answers

**Add OpenAI key:**
```bash
export OPENAI_API_KEY=sk-...
streamlit run app.py
```

---

## 🔌 Adding New Meetings

**Via UI**: Use "Add Meeting" tab in the Streamlit app.

**Via JSON**: Add entries to `data/meetings.json`:
```json
{
  "id": "meeting_006",
  "date": "2024-02-14",
  "title": "Bi-weekly Research Review",
  "transcript": "Full transcript text here..."
}
```

The index rebuilds automatically on next app load.

---

## 🧪 Running Tests

```bash
# All tests
python tests/test_all.py

# With pytest (more detailed output)
pip install pytest
pytest tests/ -v
```

Test coverage:
- Preprocessor: clean text, sentence splitting, chunking
- Extractor: keywords, NER, papers, deadlines, topics, ideas
- Embedder: shape, normalization, build+search, score ordering
- Clusterer: cluster assignment, trend detection
- RAG: context building, prompt structure
- Integration: full pipeline on real data
