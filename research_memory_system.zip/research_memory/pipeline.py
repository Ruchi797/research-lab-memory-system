"""
Module: pipeline.py
Purpose: Orchestrate the full end-to-end pipeline.

Wires together: preprocessor → extractor → embedder → clusterer → rag

This is the single entry point for the Streamlit app and CLI.
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class ResearchMemoryPipeline:
    """
    Full pipeline orchestrator.

    Usage:
        pipeline = ResearchMemoryPipeline()
        pipeline.build(meetings_json_path)          # One-time build
        results = pipeline.search("RAG pipeline")
        answer  = pipeline.ask("What papers were discussed?")
    """

    def __init__(
        self,
        data_dir: str = "data",
        llm_mode: str = "local",
        top_k: int = 5,
    ):
        self.data_dir = Path(data_dir)
        self.top_k = top_k
        self.llm_mode = llm_mode

        self.meetings: List[Dict[str, Any]] = []
        self.enriched: List[Dict[str, Any]] = []
        self.clusters: List[Dict[str, Any]] = []
        self.trends: List[Dict[str, Any]] = []
        self.repeated_ideas: List[Dict[str, Any]] = []

        self.embedder = None
        self.rag = None
        self._built = False

    def build(self, meetings_path: Optional[str] = None) -> None:
        """
        Run the full pipeline: load → preprocess → extract → embed → cluster.

        Args:
            meetings_path: Path to meetings.json. Defaults to data/meetings.json.
        """
        from modules.preprocessor import load_meetings, preprocess_all
        from modules.extractor import extract_all
        from modules.embedder import MeetingEmbedder
        from modules.clusterer import cluster_chunks, detect_trends, find_repeated_ideas
        from modules.rag_pipeline import RAGPipeline

        path = meetings_path or str(self.data_dir / "meetings.json")

        # 1. Load and preprocess
        logger.info("Step 1/5: Preprocessing meetings...")
        raw = load_meetings(path)
        processed = preprocess_all(raw)

        # 2. Extract structured insights
        logger.info("Step 2/5: Extracting insights...")
        all_texts = [m["clean_text"] for m in processed]
        self.enriched = [
            extract_all(m, all_texts, i) for i, m in enumerate(processed)
        ]
        self.meetings = self.enriched

        # 3. Build embeddings + FAISS index
        logger.info("Step 3/5: Building embedding index...")
        self.embedder = MeetingEmbedder()
        self.embedder.build_index(self.enriched)

        # Save index for reuse
        self.embedder.save(
            str(self.data_dir / "faiss_index.bin"),
            str(self.data_dir / "faiss_metadata.pkl"),
        )

        # 4. Cluster + detect trends
        logger.info("Step 4/5: Clustering and trend detection...")
        embs = self.embedder.get_all_embeddings()
        meta = self.embedder.metadata

        self.clusters = cluster_chunks(embs, meta)
        self.trends = detect_trends(self.clusters, min_meetings=2)
        self.repeated_ideas = find_repeated_ideas(embs, meta, similarity_threshold=0.80)

        # 5. Initialize RAG
        logger.info("Step 5/5: Initializing RAG pipeline...")
        self.rag = RAGPipeline(self.embedder, llm_mode=self.llm_mode, top_k=self.top_k)

        self._built = True
        logger.info("Pipeline ready.")

    def load(self, meetings_path: Optional[str] = None) -> bool:
        """
        Load pre-built index + re-run extraction (faster than full build).

        Returns True if index was loaded from disk, False if rebuild needed.
        """
        from modules.preprocessor import load_meetings, preprocess_all
        from modules.extractor import extract_all
        from modules.embedder import MeetingEmbedder
        from modules.clusterer import cluster_chunks, detect_trends, find_repeated_ideas
        from modules.rag_pipeline import RAGPipeline

        path = meetings_path or str(self.data_dir / "meetings.json")
        index_path = str(self.data_dir / "faiss_index.bin")
        meta_path = str(self.data_dir / "faiss_metadata.pkl")

        # Always re-run preprocessing + extraction (fast, < 1s)
        raw = load_meetings(path)
        processed = preprocess_all(raw)
        all_texts = [m["clean_text"] for m in processed]
        self.enriched = [
            extract_all(m, all_texts, i) for i, m in enumerate(processed)
        ]
        self.meetings = self.enriched

        # Try loading saved index
        self.embedder = MeetingEmbedder()
        loaded = self.embedder.load(index_path, meta_path)

        if not loaded:
            # Rebuild if not found
            self.embedder.build_index(self.enriched)
            self.embedder.save(index_path, meta_path)

        # Clustering
        embs = self.embedder.get_all_embeddings()
        meta = self.embedder.metadata
        self.clusters = cluster_chunks(embs, meta)
        self.trends = detect_trends(self.clusters, min_meetings=2)
        self.repeated_ideas = find_repeated_ideas(embs, meta, similarity_threshold=0.80)

        self.rag = RAGPipeline(self.embedder, llm_mode=self.llm_mode, top_k=self.top_k)
        self._built = True
        return loaded

    def search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Semantic search over all meeting chunks."""
        self._check_built()
        return self.embedder.search(query, top_k=top_k)

    def ask(self, question: str) -> Dict[str, Any]:
        """Answer a question using RAG."""
        self._check_built()
        return self.rag.answer(question)

    def get_meeting_insights(self, meeting_id: str) -> Optional[Dict[str, Any]]:
        """Get all extracted insights for a specific meeting."""
        return next((m for m in self.enriched if m["id"] == meeting_id), None)

    def _check_built(self):
        if not self._built:
            raise RuntimeError("Pipeline not built. Call build() or load() first.")
